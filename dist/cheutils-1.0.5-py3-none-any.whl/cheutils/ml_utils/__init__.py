# Define a package-level variable
__version__ = '1.0.1'
# Import the required modules into the package namespace
from . import model_builder, model_options, pipeline_details, visualize
from cheutils import *