# cheutils

A set of basic reusable utilities to and tools to facilitate quickly getting up and going on any project.

### Packages

- cheutils: basic utilities.
- ml_utils: ML unitilies.

### Usage

```
import cheutils

# retrieve the path to the data folder, which is under the project root
cheutils.project_tree.get_data_dir()  # returns the path

```
