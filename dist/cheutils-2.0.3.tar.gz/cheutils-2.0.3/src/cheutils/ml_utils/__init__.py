from .model_options import (get_regressor, get_hyperopt_regressor, get_params_grid, get_params_pounds,
                            get_default_grid, get_params)
from .model_builder import (fit, predict, exclude_nulls, score, eval_metric_by_params, tune_model, coarse_fine_tune,
                            get_narrow_param_grid, get_seed_params, get_optimal_num_params, parse_params, cross_val_model, cross_val_score)
from .bayesian_search import HyperoptSearch
from .visualize import (plot_hyperparameter, plot_reg_residuals, plot_pie, plot_reg_predictions,
                        plot_reg_residuals_dist, plot_reg_predictions_dist)
from .pipeline_details import show_pipeline, save_to_html
from .. import APP_PROPS
from .. import DBUGGER
prop_key = 'project.models.supported'
MODELS_SUPPORTED = APP_PROPS.get_list(prop_key)
assert (MODELS_SUPPORTED is not None), 'Models supported must be specified'
DBUGGER.debug('Models supported = ', MODELS_SUPPORTED)
N_JOBS = -1
# the model option selected as default
MODEL_OPTION = APP_PROPS.get('model.active.model_option')
# number of iterations or parameters to sample
N_ITERS = int(APP_PROPS.get('model.n_iters.to_sample'))
# number of hyperopt trials to iterate over
N_TRIALS = int(APP_PROPS.get('model.n_trials.to_sample'))
# max number of parameters to create for narrower param_grip - which defines how finely discretized the grid is
CONFIGURED_NUM_PARAMS = int(APP_PROPS.get('model.num_params.to_sample'))
# determine optimal number of parameters automatically, using the range specified as the boundary
USE_OPTIMAL_NUM_PARAMS = APP_PROPS.get_bol('model.num_params.find_optimal')
NUM_PARAMS_RANGE = [int(APP_PROPS.get_dict_properties('model.num_params.sample_range').get('start')),
                       int(APP_PROPS.get_dict_properties('model.num_params.sample_range').get('end'))]
# the cross_validation scoring metric
SCORING = APP_PROPS.get('model.cross_val.scoring')
CV = int(APP_PROPS.get('model.cross_val.num_folds'))
RANDOM_SEED = int(APP_PROPS.get('model.random_seed'))
# the hyperopt trial timeout
TRIAL_TIMEOUT = int(APP_PROPS.get('model.trial_timeout'))
# whether grid search is on
GRID_SEARCH_ON = APP_PROPS.get_bol('model.tuning.grid_search.on')
# cache narrower parameter grid, keyed by num_params
NARROW_PARAM_GRIDS = {}
# cache optimal num_params, keyed by model option
OPTIMAL_NUM_PARAMS = {}