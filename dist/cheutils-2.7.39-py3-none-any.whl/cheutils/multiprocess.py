import os
import dill
from multiprocessing import Process

"""
See also: https://stackoverflow.com/questions/72766345/attributeerror-cant-pickle-local-object-in-multiprocessing
This is a useful replacement for multiprocessing.Process in cases where inner functions are used
"""
class CheutilsProcess(Process):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._target = dill.dumps(self._target)  # Save the target function as bytes, using dill

    def run(self):
        if self._target:
            self._target = dill.loads(self._target)    # Unpickle the target function before executing
            self._target(*self._args, **self._kwargs)  # Execute the target function